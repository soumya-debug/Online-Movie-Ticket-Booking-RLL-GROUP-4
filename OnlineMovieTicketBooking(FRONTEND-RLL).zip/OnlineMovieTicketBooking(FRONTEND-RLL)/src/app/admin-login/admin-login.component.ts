import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommunicationService } from '../communication.service';
import { Router } from '@angular/router';

// Define the interface for the response
interface LoginResponse {
  result: string;
}

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css'],
})
export class AdminLoginComponent implements OnInit {
  loginForm: FormGroup;
  message: string;

  constructor(
    private fb: FormBuilder,
    private communicationService: CommunicationService,
    private router: Router // Inject the Router module
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const loginData = this.loginForm.value;
      this.communicationService.loginAdmin(loginData).subscribe(
        (response: LoginResponse | string) => {
          if (typeof response === 'string') {
            response = JSON.parse(response) as LoginResponse;
          }

          if (response.result === 'success') {
            // Admin login successful, redirect to admin dashboard
            this.message = '';
            this.router.navigate(['/admin/movies']); // Add navigation to admin dashboard
          } else {
            // Admin login failed, show error message
            this.message = 'Invalid admin credentials';
          }
        },
        (error) => {
          console.error(error);
          // Handle any error that occurs during the API call
          this.message = 'An error occurred while processing the request';
        }
      );
    }
  }
}