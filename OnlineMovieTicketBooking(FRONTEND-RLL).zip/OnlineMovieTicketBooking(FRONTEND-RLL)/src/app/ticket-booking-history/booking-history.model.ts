export interface BookingHistoryDTO {
  id: number;
  user: string;
  movie: string;
  theater: string;
  cardHolderName: string;
  cardNumber: string;
}
