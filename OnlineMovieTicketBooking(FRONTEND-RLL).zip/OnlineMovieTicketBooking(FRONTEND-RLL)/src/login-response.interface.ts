interface LoginResponse {
    result: string;
  }